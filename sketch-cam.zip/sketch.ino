#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include "esp_camera.h"
#include <Preferences.h>
#define PWDN_GPIO_NUM -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM 10
#define SIOD_GPIO_NUM 40
#define SIOC_GPIO_NUM 39
#define Y9_GPIO_NUM 48
#define Y8_GPIO_NUM 11
#define Y7_GPIO_NUM 12
#define Y6_GPIO_NUM 14
#define Y5_GPIO_NUM 16
#define Y4_GPIO_NUM 18
#define Y3_GPIO_NUM 17
#define Y2_GPIO_NUM 15
#define VSYNC_GPIO_NUM 38
#define HREF_GPIO_NUM 47
#define PCLK_GPIO_NUM 13
#define LED_GPIO_NUM 21
#define capturePin D0
#define LEDAnode D5
#define statusLED D6
#define captureLED D4

Preferences preferences; // Preferences object to store non-volatile values
unsigned long lastPressTime = 0; // Last button press start time
unsigned long pressDuration = 0; // Duration of the button press
int imageCount = 1;              // File Counter
bool camera_sign = false;        // Check camera status
bool sd_sign = false;            // Check SD card status

void photo_save(const char *fileName) {
  // Take a photo
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) {
    Serial.println("Failed to get camera frame buffer");
    return;
  }
  // Save photo to file
  writeFile(SD, fileName, fb->buf, fb->len);
  // Release image buffer
  esp_camera_fb_return(fb);
  Serial.println("Photo saved to file");
}

void writeFile(fs::FS &fs, const char *path, uint8_t *data, size_t len) {
  Serial.printf("Writing file: %s\n", path);
  File file = fs.open(path, FILE_WRITE);
  if (!file) {
    Serial.println("Failed to open file for writing");
    return;
  }
  if (file.write(data, len) == len) {
    Serial.println("File written");
  } else {
    Serial.println("Write failed");
  }
  file.close();
}

void setup() {
  Serial.begin(115200);
  pinMode(capturePin, INPUT_PULLUP);
  pinMode(statusLED, OUTPUT); // Initialize LED pin as an output
  pinMode(LEDAnode, OUTPUT);
  pinMode(captureLED, OUTPUT);
  digitalWrite(LEDAnode, HIGH); // I am using a common anode RGB LED
  digitalWrite(captureLED, HIGH);
  // Initialize Preferences
  preferences.begin("camera", false);
  // Retrieve the stored image count from non-volatile memory
  imageCount = preferences.getInt("imageCount", 1); // Default to 1 if not set
  // Initialize camera
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.frame_size = FRAMESIZE_UXGA;
  config.pixel_format = PIXFORMAT_JPEG;
  config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location = CAMERA_FB_IN_PSRAM;
  config.jpeg_quality = 12;
  config.fb_count = 1;
  if (config.pixel_format == PIXFORMAT_JPEG) {
    if (psramFound()) {
      config.jpeg_quality = 10;
      config.fb_count = 2;
      config.grab_mode = CAMERA_GRAB_LATEST;
    } else {
      config.frame_size = FRAMESIZE_SVGA;
      config.fb_location = CAMERA_FB_IN_DRAM;
    }
  } else {
    config.frame_size = FRAMESIZE_240X240;
  }
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }
  camera_sign = true;
  // Initialize SD card
  if (!SD.begin(21)) {
    Serial.println("Card Mount Failed");
    return;
  }
  uint8_t cardType = SD.cardType();
  if (cardType == CARD_NONE) {
    Serial.println("No SD card attached");
    return;
  }
  sd_sign = true;
  Serial.println("*** XIAO ESP32S3 Spy Camera ***");
  Serial.println("Press and hold the button to enter deep sleep.");
  Serial.println("Press the button briefly to capture an image.");
  esp_sleep_enable_ext0_wakeup(static_cast<gpio_num_t>(capturePin), 0);
  digitalWrite(statusLED, LOW);
  digitalWrite(captureLED, HIGH);
}

void loop() { handleButtonPress(); }


void handleButtonPress() {
  int buttonState = digitalRead(capturePin);
  if (buttonState == LOW) {
    if (lastPressTime == 0) {
      lastPressTime = millis(); // Record the press start time
    }
    pressDuration = millis() - lastPressTime;
    if (pressDuration > 2000) { // Long press detection (>2 seconds)
      Serial.println("Long press detected: Going to deep sleep");
      digitalWrite(statusLED, HIGH);
      delay(1000);     // Delay to debounce before deep sleep
      goToDeepSleep(); // Enter deep sleep
    }
  } else {
    if (lastPressTime > 0 && pressDuration > 100 &&
        pressDuration < 1000) { // Short press detection
      Serial.println("Short press detected: Taking picture");
      digitalWrite(captureLED, LOW);
      captureImage();
      digitalWrite(captureLED, HIGH);
    }
    lastPressTime = 0; // Reset timing when the button is released
    pressDuration = 0;
  }
}

void captureImage() {
  char filename[32];
  sprintf(filename, "/image%d.jpg", imageCount);
  photo_save(filename); // Capture the image and save it
  Serial.printf("Saved picture: %s\n", filename);
  imageCount++;
  // Store the new imageCount in non-volatile memory
  preferences.putInt("imageCount", imageCount);
}

void goToDeepSleep() {
  // Store image count before going to sleep
  preferences.putInt("imageCount", imageCount);
  preferences.end(); // Close preferences
  digitalWrite(statusLED, HIGH);
  esp_deep_sleep_start(); // Enter deep sleep
}